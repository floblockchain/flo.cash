Florincoin - the first coin to feature transaction comments

 - Fast block generation: 40 second block targets
 - subsidy halves in 800k blocks (~1 year)
 - ~160 million total coins 
 - 100 coins per block
 - 90 blocks to retarget difficulty
 - A comments field can be included in a transaction for use between coin sender and receiver.

http://www.florincoin.org/
